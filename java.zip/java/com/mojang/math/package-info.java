@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package com.mojang.math;

import javax.annotation.ParametersAreNonnullByDefault;